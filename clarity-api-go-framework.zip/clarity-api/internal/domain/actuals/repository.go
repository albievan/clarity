package actuals

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/computershare/clarity-api/internal/db"
)

// Repository defines the data-access contract for the actuals domain.
type Repository interface {
	List(ctx context.Context, tenantID string, page, perPage int) ([]Actual, int, error)
	GetByID(ctx context.Context, tenantID, id string) (*Actual, error)
	Create(ctx context.Context, tenantID string, req CreateRequest) (*Actual, error)
	Update(ctx context.Context, tenantID, id string, req UpdateRequest) (*Actual, error)
	Delete(ctx context.Context, tenantID, id string) error
}

type repository struct {
	db *db.DB
}

func NewRepository(database *db.DB) Repository {
	return &repository{db: database}
}

func (r *repository) List(ctx context.Context, tenantID string, page, perPage int) ([]Actual, int, error) {
	// TODO: SELECT ... FROM actuals WHERE tenant_id=$1 LIMIT $2 OFFSET $3
	_ = tenantID
	return nil, 0, fmt.Errorf("actuals.List: not implemented")
}

func (r *repository) GetByID(ctx context.Context, tenantID, id string) (*Actual, error) {
	row := r.db.QueryRowContext(ctx,
		`SELECT id, tenant_id, created_at, updated_at FROM actuals WHERE tenant_id=$1 AND id=$2 LIMIT 1`,
		tenantID, id,
	)
	var m Actual
	err := row.Scan(&m.ID, &m.TenantID, &m.CreatedAt, &m.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("actuals.GetByID: %w", err)
	}
	return &m, nil
}

func (r *repository) Create(ctx context.Context, tenantID string, req CreateRequest) (*Actual, error) {
	// TODO: INSERT INTO actuals (...)
	_ = req
	return nil, fmt.Errorf("actuals.Create: not implemented")
}

func (r *repository) Update(ctx context.Context, tenantID, id string, req UpdateRequest) (*Actual, error) {
	// TODO: UPDATE actuals SET ... WHERE tenant_id=$1 AND id=$2
	_ = req
	return nil, fmt.Errorf("actuals.Update: not implemented")
}

func (r *repository) Delete(ctx context.Context, tenantID, id string) error {
	// TODO: soft or hard delete depending on domain rules
	return fmt.Errorf("actuals.Delete: not implemented")
}
